const mongoose = require('mongoose')
const Product = require('../Model/productModel')

exports.getAllProduct = async (req,resp,next)=>{
  try{
  const getAllProduct = await Product.find().populate()

  resp.status(200).json({
    status:'success',
    data:{
      getAllProduct
    }
  })
}catch(err){
  resp.status(400).json({
    status:'fail',
    err:err.message
  })
}
}














exports.createProduct = async (req, resp,next) => {
  try {
    const newPro = await Product.create(req.body)

    resp.status(200).json({
      status: 'success',
      data: {
        newPro
      }
    })
  } catch (err) {
    resp.status(400).json({
      status: 'fail',
      err: err.message
    })
  }
}


exports.updateProduct = async (req, resp,next) => {
  try{
  const product =  await Product.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runvalidators: true
  })

  resp.status(200).json({
    status:'success',
    data:{
      product
    }
  })
}catch(err){
  resp.status(200).json({
    err:err.message
  })
}
}


exports.getProduct = async (req,resp,next)=>{
  try{
    const handle = req.params.slug

  const product = await Product.findOne({handle})

  resp.status(200).json({
    status:'success',
    data:{
      product
    }
  })
}catch(err){
  resp.status(400).json({
    status:'fail',
    err:err.message
  })
}
}


exports.deleteProduct = async(req,resp,next)=>{
  try{
  const product = await Product.findByIdAndDelete(req.params.id)


  if(!product) { 
    return resp.json({message:'Product not found with that id'}) }

  resp.status(200).json({
    status:'success',
    data:null
  })

 

}catch(err){
  resp.status(400).json({
    status:'fail',
    err:err.message
  })
}
}



