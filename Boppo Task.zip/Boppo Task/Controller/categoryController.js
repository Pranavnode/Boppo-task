const Category = require('../Model/categoryModel')

exports.createCategory = async (req,resp)=>{
  try{
  const newCat = await Category.create(req.body)

  resp.status(200).json({
    status:'success',
    data: newCat
  })
} catch(err) {
  resp.status(400).json({
    err:err.message
  })
}
}


exports.getAllCategory = async (req,resp,next)=>{
  try{
  const category = await Category.find()

  resp.status(200).json({
    status:'Success',
    data:category
  })
}catch(err){
  err = err.message
}
}