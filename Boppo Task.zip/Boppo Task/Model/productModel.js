const mongoose = require('mongoose')
const slugify = require('slugify')

const productSchema = mongoose.Schema({
  name:{
    type:String,
  },
  category:{
    type:mongoose.Schema.ObjectId,
    ref:'Category',
    // required:[true, 'A product must belong to a category']
  },
  price:{
    type:Number,
  },
  description:{
    type:String,
    required:[true,'Description required']
  },
  slug:String

})


productSchema.pre('save', function (next) {
  this.slug = slugify(this.name, {
    lower: true
  })
  next()
})

module.exports = mongoose.model('Product',productSchema)