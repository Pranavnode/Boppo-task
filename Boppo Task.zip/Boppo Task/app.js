const dotenv = require('dotenv').config()
const express = require('express')
const app = express()
app.use(express.json())
const categoryRouter = require('./Routes/categoryRoutes')
const productRouter = require('./Routes/productRoutes')
const connectDb = require('./connectDb')

const PORT = process.env.PORT || 3001


app.use('/api/v1/category',categoryRouter)
app.use('/api/v1/product',productRouter)
connectDb()




const server = app.listen(PORT,()=>{
console.log(`Server running on ${PORT}`)
})