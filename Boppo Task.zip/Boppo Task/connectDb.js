const mongoose = require('mongoose')

const DB = process.env.DATABASE_URL

const connectDb = async()=>{ await mongoose.connect(DB,{
  useUnifiedTopology: true,
  useNewUrlParser: true,
})
console.log('DB connected successfully')
}

module.exports = connectDb