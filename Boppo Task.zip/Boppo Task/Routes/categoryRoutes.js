const express = require('express')
const router = express.Router()
const categoryController = require('../Controller/categoryController')

router.route('/add').post(categoryController.createCategory)

router.route('all').get(categoryController.getAllCategory)


module.exports = router