const express = require('express')
const router = express.Router()
const productController = require('../Controller/productController')

router.route('/add').post(productController.createProduct)

router.route('/product').get(productController.getAllProduct)


router.route('/update/:id')
.patch(productController.updateProduct)


router.route('/delete/:productId').delete(productController.deleteProduct)

router.route('/:getByHandle').get(productController.getProduct)

module.exports = router